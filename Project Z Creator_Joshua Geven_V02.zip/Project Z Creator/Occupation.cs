﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Z_Creator
{
    class Occupation
    {
            
        public int chosenOccupation;

        public enum Occupations
        {
            Unemployed = 0,
            FireOfficer = -8,
            PoliceOfficer = -12,
            ParkRanger = -12,
            ContructionWorker = -10,
            SecurityGuard = -10,
            Carpenter = -6,
            Burglar = -14,
            Chef = -12,
            Repairman = -12,
            Farmer = -6,
            Fisherman = -10,
            Doctor = -6,
            Veteran = -16,
            Nurse = -6,
            Lumberjack = -8,
            FitnessInstructor = -14,
            BurgerFlipper = -6,
            Electrician = -12,
            Engineer = -12,
            Metalworker = -14,
            Mechanic = -12
        }

        //switch ()

    }
}

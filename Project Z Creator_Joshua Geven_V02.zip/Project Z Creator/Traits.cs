﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Z_Creator
{
    class Traits
    {


        public enum PosTraits
        {
            Handy = -8,
            Brave = -4,
            Graceful = -4,
            KeenHearing = -6,
            EagleEyed = -6,
            LightEater = -4,
            ThickSkinned = -6,
            Fit = -6,
            Athletic = -10,
            Nutritionist = -4,
            Speeddemon = -1,
            Strong = -10,
            Stout = -6,
            Resilient = -4,
            Lucky = -4,
            Outdoorsman = -2,
            FastHealer = -6,
            FastLearner = -6,
            FastReader = -2,
            AdrenalineJunkie = -8,
            Inconspicuous = -4,
            Wakeful = -2,
            CatsEyes = -2,
            Organized = -6,
            LowThirst = -6,
            SelfDefenseClass = -6,
            FirstAider = -4,
            Angler = -4,
            Gardener = -4,
            Runner = -4,
            Dextrous = -2,
            IronGut = -3,
            Herbalist = -6,
            Brawler = -6,
            FormerScout = -6,
            BaseballPlayer = -4,
            Hiker = -6,
            Hunter = -8,
            Gymnast = -5,
            Cook = -6,
            Mechanincs = -5
        }

        public enum NegTraits
        {
            Cowardly = 2,
            Clumsy = 2,
            Hypochondriac = 2,
            ShortSighted = 2,
            HardofHearing = 2,
            Deaf = 12,
            HeartyAppetite = 4,
            Unfit = 10,
            OutofShape = 6,
            Emaciated = 10,
            VeryUnderweight = 10,
            UnderWeight = 6,
            Overweight = 6,
            Smoker = 4,
            Obese = 10,
            Weak = 10,
            SundayDriver = 1,
            Feeble = 6,
            PronetoIllness = 4,
            Agoraphobic = 4,
            Claustrophobic = 4,
            Unlucky = 4,
            SlowHealer = 6,
            SlowLearner = 6,
            SlowReader = 2,
            Sleepyhead = 4,
            Conspicuous = 4,
            Disorganized = 4,
            HighThirst = 6,
            Illiterate = 8,
            RestlessSleeper = 6,
            Pacifist = 4,
            ThinSkinned = 6,
            AllThumbs = 2,
            WeakStomache = 3,
            Hemophobic = 3,
            Asthmatic = 5
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Z_Creator
{
    public partial class Form1 : Form
    {
        Occupation Occupation = new Occupation();
        Traits Trait = new Traits();


        private int totalPoints;


        public Form1()
        {
            InitializeComponent();

            Type Occupation = typeof(Occupation.Occupations);
            Type PosTraits = typeof(Traits.PosTraits);
            Type NegTraits = typeof(Traits.NegTraits);


            cbOccupations.DataSource = Enum.GetNames(typeof(Occupation.Occupations));
            cbPosTraits.DataSource = Enum.GetNames(typeof(Traits.PosTraits));
            cbNegTraits.DataSource = Enum.GetNames(typeof(Traits.NegTraits));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
       

        }

        private void cbPosTraits_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbChosenTraits.Items.Add(cbPosTraits.SelectedItem);
        }

        private void cbNegTraits_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbChosenTraits.Items.Add(cbNegTraits.SelectedItem);
        }

        private void lbChosenTraits_DoubleClick(object sender, EventArgs e)
        {
            lbChosenTraits.Items.Remove(lbChosenTraits.SelectedItem);
        }

        private void lbChosenTraits_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbPoints.Text = "Points to Spend:" + totalPoints;
        }
    }
}
